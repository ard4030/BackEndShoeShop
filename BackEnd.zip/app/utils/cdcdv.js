module.exports = {
    SUPERADMIN : 'SUPERADMIN', // All Permission
    ADMIN : 'ADMIN', // Discount - Add & Edit Product - Categorys - Vizhegiha - PostMethod - Discount - Orders - Payment Setting
    USER : 'USER', // All Public For Users
    ORDER : 'ORDER', // Orders => Change Status
}