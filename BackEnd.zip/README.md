const autoBind = require("auto-bind");
  constructor(){
    autoBind(this)
  }